# Assignment 1 - *assignment_1calculator*

**Project Name** Project description.

Team Name:
* **Zongcheng Wang**
- zongchew
* **Zehua Wang**
- zehuaw6

## Functionalities
[//]: # (Write [x] to mark off what was accomplished.<br/>)
The following **required** functionality is complete:

* [x] Inputs can be added via command line
* [x] Returns correct value for fully parenthetical expressions
* [x] Considers negative numbers

[//]: # (* [ ] Got any features?)
The following **additional** features are implemented:<br/>
* [x] Considers decimal values

